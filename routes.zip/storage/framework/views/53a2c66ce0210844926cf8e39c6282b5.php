<?php $__env->startSection('title', 'Edit Unit - boysonthewheels'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8 max-w-4xl">

    <div class="mb-6 border-b border-gray-700 pb-4 flex justify-between items-center">
        <div>
            <h1 class="text-3xl font-bold text-white brand-font">EDIT KATALOG</h1>
            <p class="text-gray-400 text-sm mt-1">Update informasi unit: <span class="text-botw-red font-bold"><?php echo e($car->name); ?></span></p>
        </div>
        <a href="<?php echo e(route('dashboard.cars.index')); ?>" class="text-gray-400 hover:text-white transition"><i class="fas fa-arrow-left"></i> Kembali</a>
    </div>

    <?php if($errors->any()): ?>
    <div class="bg-red-900/50 border border-red-500 text-red-200 p-4 rounded-lg mb-6">
        <ul class="list-disc list-inside">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <form action="<?php echo e(route('dashboard.cars.update', $car)); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?> <div class="bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-lg">
            <h2 class="text-xl font-bold text-botw-blue mb-4 brand-font">Identitas Mobil</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Merek</label>
                    <input type="text" name="brand" value="<?php echo e(old('brand', $car->brand)); ?>" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red focus:outline-none">
                </div>
                <div>
                    <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Nama Unit</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $car->name)); ?>" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red focus:outline-none">
                </div>
                <div>
                    <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Tahun</label>
                    <input type="number" name="year" value="<?php echo e(old('year', $car->year)); ?>" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red focus:outline-none">
                </div>
                <div>
                    <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Model / Kategori</label>
                    <select name="body_type" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red focus:outline-none">
                        <?php $__currentLoopData = ['City Car', 'Sedan', 'Mobil Keluarga', 'SUV']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($option); ?>" <?php echo e(old('body_type', $car->body_type) == $option ? 'selected' : ''); ?>><?php echo e($option); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Kapasitas Baris Kursi</label>
                    <select name="row_type" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red focus:outline-none">
                        <option value="2 baris" <?php echo e(old('row_type', $car->row_type) == '2 baris' ? 'selected' : ''); ?>>2 Baris</option>
                        <option value="3 baris" <?php echo e(old('row_type', $car->row_type) == '3 baris' ? 'selected' : ''); ?>>3 Baris</option>
                        <option value="Lebih dari 3 baris" <?php echo e(old('row_type', $car->row_type) == 'Lebih dari 3 baris' ? 'selected' : ''); ?>>Lebih dari 3 Baris</option>
                    </select>
                </div>
            </div>
        </div>

        <div class="bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-lg">
            <h2 class="text-xl font-bold text-botw-blue mb-4 brand-font">Spesifikasi & Finansial</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Transmisi</label>
                    <select name="transmission" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red">
                        <option value="Automatic" <?php echo e($car->transmission == 'Automatic' ? 'selected' : ''); ?>>Automatic</option>
                        <option value="Manual" <?php echo e($car->transmission == 'Manual' ? 'selected' : ''); ?>>Manual</option>
                    </select>
                </div>
                <div>
                    <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Odometer (KM)</label>
                    <input type="number" name="mileage" value="<?php echo e(old('mileage', $car->mileage)); ?>" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red">
                </div>
                <div>
                    <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Harga Cash</label>
                    <input type="number" name="price" value="<?php echo e(old('price', $car->price)); ?>" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red font-bold">
                </div>
                <div>
                    <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Min. DP</label>
                    <input type="number" name="down_payment" value="<?php echo e(old('down_payment', $car->down_payment)); ?>" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red">
                </div>
                <div class="md:col-span-2">
                    <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Estimasi Angsuran</label>
                    <input type="number" name="installment" value="<?php echo e(old('installment', $car->installment)); ?>" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red font-bold text-green-400">
                </div>
            </div>
        </div>

        <div class="bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-lg">
            <h2 class="text-xl font-bold text-botw-blue mb-4 brand-font">Media & Deskripsi</h2>

            <div class="mb-6">
                <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Link Video Review</label>
                <input type="url" name="video_link" value="<?php echo e(old('video_link', $car->video_link)); ?>" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red">
            </div>

            <div class="mb-6">
                <label class="block text-gray-400 text-xs font-bold mb-2 uppercase">Deskripsi</label>
                <textarea name="description" rows="5" class="w-full bg-gray-900 border border-gray-600 text-white rounded p-3 focus:border-botw-red"><?php echo e(old('description', $car->description)); ?></textarea>
            </div>

            <div class="mb-6">
                <div class="flex justify-between items-end mb-2">
                    <label class="block text-gray-400 text-xs font-bold uppercase">Atur Foto</label>
                    <span class="text-xs text-gray-500 italic text-right">
                        *Foto <strong>LAMA</strong> bisa digeser urutannya.<br>
                        *Foto <strong>BARU</strong> akan muncul di paling belakang (setelah disimpan).
                    </span>
                </div>

                <div id="sortable-images" class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">

                    <?php $__currentLoopData = $car->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="existing-image relative group cursor-move bg-gray-900 rounded-lg border <?php echo e($img->is_primary ? 'border-botw-red ring-1 ring-botw-red' : 'border-gray-600'); ?> p-1" data-id="<?php echo e($img->id); ?>">

                        <img src="<?php echo e(asset('storage/' . $img->image_path)); ?>" class="w-full h-32 object-cover rounded">

                        <label class="absolute top-2 left-2 cursor-pointer z-20">
                            <input type="radio" name="primary_image_id" value="<?php echo e($img->id); ?>" <?php echo e($img->is_primary ? 'checked' : ''); ?> class="hidden peer">
                            <div class="w-6 h-6 rounded-full border-2 border-white bg-gray-800/50 peer-checked:bg-botw-red peer-checked:border-botw-red flex items-center justify-center transition shadow-lg">
                                <i class="fas fa-star text-[10px] text-white <?php echo e($img->is_primary ? '' : 'hidden'); ?>"></i>
                            </div>
                        </label>

                        <button type="button" onclick="confirmDeleteImage(<?php echo e($img->id); ?>)" class="absolute top-2 right-2 bg-red-600 text-white w-6 h-6 rounded flex items-center justify-center hover:bg-red-700 shadow-lg transition z-20">
                            <i class="fas fa-trash text-xs"></i>
                        </button>

                        <div class="absolute bottom-1 right-1 bg-black/50 text-white text-[10px] px-2 rounded backdrop-blur-sm z-10">
                            #<span class="position-label"><?php echo e($loop->iteration); ?></span>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <input type="hidden" name="image_order" id="image_order_input">

                <label for="file-input" class="flex flex-col items-center justify-center w-full h-24 border-2 border-gray-600 border-dashed rounded-lg cursor-pointer bg-gray-900 hover:bg-gray-800 hover:border-botw-red transition mb-4">
                    <div class="flex flex-col items-center justify-center pt-2">
                        <i class="fas fa-cloud-upload-alt text-2xl text-gray-400 mb-1"></i>
                        <p class="text-sm text-gray-400 font-bold">Tambah Foto Baru</p>
                        <p class="text-xs text-gray-500">Klik disini untuk memilih foto tambahan</p>
                    </div>
                    <input id="file-input" name="images[]" type="file" multiple class="hidden" onchange="previewNewImages(event)" />
                </label>
            </div>
        </div>

        <div class="flex items-center gap-4 pt-4">
            <button type="submit" class="bg-botw-red text-white font-bold px-8 py-4 rounded-lg shadow-lg hover:bg-red-700 transition w-full md:w-auto">
                <i class="fas fa-save mr-2"></i> UPDATE DATA
            </button>
        </div>
    </form>

    <form id="delete-image-form" method="POST" class="hidden">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
<script>
    // 1. LOGIC DELETE IMAGE (SERVER SIDE)
    function confirmDeleteImage(id) {
        if (confirm('Hapus foto ini dari database?')) {
            let form = document.getElementById('delete-image-form');
            form.action = '/dashboard/cars/image/' + id; // Pastikan route ini ada
            form.submit();
        }
    }

    // 2. LOGIC PREVIEW NEW IMAGES (CLIENT SIDE)
    let newFilesArray = []; // Menyimpan file baru
    const sortableContainer = document.getElementById('sortable-images');
    const fileInput = document.getElementById('file-input');

    function previewNewImages(event) {
        const files = Array.from(event.target.files);

        // Loop setiap file baru
        files.forEach((file, index) => {
            // Masukkan ke array global (opsional jika ingin fitur hapus sebelum upload)
            newFilesArray.push(file);

            const reader = new FileReader();
            reader.onload = function(e) {
                // Buat elemen DIV baru
                const div = document.createElement('div');
                div.className = "relative group bg-gray-800 rounded-lg border-2 border-dashed border-botw-blue p-1 opacity-90";

                // HTML Content untuk Foto Baru
                div.innerHTML = `
                    <img src="${e.target.result}" class="w-full h-32 object-cover rounded opacity-70">

                    <div class="absolute top-1 left-1 bg-botw-blue text-white text-[10px] px-2 rounded-full font-bold shadow z-20">
                        NEW
                    </div>

                    <button type="button" onclick="this.parentElement.remove()" class="absolute top-1 right-1 bg-gray-600 text-white w-6 h-6 rounded flex items-center justify-center hover:bg-gray-500 shadow z-20">
                        <i class="fas fa-times text-xs"></i>
                    </button>

                    <div class="absolute bottom-1 right-1 text-[10px] text-gray-300 italic px-1">
                        Belum Disimpan
                    </div>
                `;

                // Tambahkan ke Grid Sortable
                sortableContainer.appendChild(div);
            }
            reader.readAsDataURL(file);
        });
    }

    // 3. LOGIC SORTABLE (DRAG & DROP FOTO LAMA)
    document.addEventListener('DOMContentLoaded', function() {
        var el = document.getElementById('sortable-images');
        var orderInput = document.getElementById('image_order_input');

        var sortable = Sortable.create(el, {
            animation: 150,
            draggable: ".existing-image", // HANYA FOTO LAMA YANG BISA DIGESER
            ghostClass: 'opacity-50',
            onEnd: function() {
                updateOrder();
                updateLabels();
            }
        });

        function updateOrder() {
            // Hanya ambil ID dari foto lama (yang punya data-id)
            var order = [];
            var items = el.querySelectorAll('.existing-image');
            items.forEach(function(item) {
                order.push(item.getAttribute('data-id'));
            });
            orderInput.value = order.join(',');
        }

        function updateLabels() {
            // Update nomor urut visual
            var labels = el.querySelectorAll('.position-label');
            labels.forEach(function(span, index) {
                span.textContent = index + 1;
            });
        }

        // Init awal
        updateOrder();
    });
</script>
<script>
    function confirmDeleteImage(id) {
        if (confirm('Hapus foto ini?')) {
            let form = document.getElementById('delete-image-form');
            form.action = '/dashboard/cars/image/' + id;
            form.submit();
        }
    }
</script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\car\resources\views/admin/cars/edit.blade.php ENDPATH**/ ?>